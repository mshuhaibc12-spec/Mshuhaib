SHUHAIB & NIHALA WEDDING INVITATION

Files to upload together: index.html, kudmayi.mp3, couple.png.

Open index.html for a local preview. When a guest taps “Tap to Open Invitation”, the site attempts to start Kudmayi immediately from that tap. This is the most reliable method on phones, but no website can guarantee autoplay on every browser/device; if blocked, guests can tap the ♫ Kudmayi button.

To publish: extract this ZIP and upload the folder contents together to a static hosting service such as Netlify Drop. The public site is not live until you publish it.

Note: Wishes currently save only in each visitor’s own browser. Shared public wishes require a database/backend.
